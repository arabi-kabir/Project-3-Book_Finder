<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('user')->user_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('my_added_book_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 id="page-heading">Book Information</h1>
    <hr>
    <div class="">
        <div class="row">
            <div class="col-6">
                <table class="table table-bordered">
                  <tbody>
                    <tr>
                      <th scope="row">Book Name</th>
                      <td><?php echo e($book->book_name); ?></td>

                    </tr>
                  </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.HomeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>