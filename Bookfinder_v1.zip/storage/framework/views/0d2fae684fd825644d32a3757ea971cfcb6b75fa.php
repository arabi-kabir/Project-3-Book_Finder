<?php if($errors->any()): ?>
    <br>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <p class="alert alert-danger"><?php echo e($err); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('error_message')): ?>
    <div>
        <p class="alert alert-danger"><?php echo e(session('error_message')); ?></p>
    </div>
<?php endif; ?>

<?php if(session('success_message')): ?>
    <div>
        <p class="alert alert-success"><?php echo e(session('success_message')); ?></p>
    </div>
<?php endif; ?>
