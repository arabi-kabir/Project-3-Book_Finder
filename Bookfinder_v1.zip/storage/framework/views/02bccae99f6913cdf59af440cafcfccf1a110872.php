<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('user')->user_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('my_collection_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 id="page-heading">Books in my collection</h1>
    <hr>
    <div class="">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add Book in the List</button>

        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Book</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="post">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Book From (My Added Book):</label>
                    <select class="form-control" name="book">
                        <?php $__currentLoopData = $myAddedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($book->book_id); ?>"><?php echo e($book->book_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
              </div>

            </div>
          </div>
        </div>
        <div id="msg_padding">
            <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <table class="table table-bordered">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Book Name</th>
                <th scope="col">Category </th>
                <th scope="col">Writer</th>
                <th scope="col">Remove</th>
            </tr>
            <tbody>
                <?php $i=1 ?>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($book->book_name); ?></td>
                        <td><?php echo e($book->book_category); ?></td>
                        <td><?php echo e($book->book_writer_name); ?></td>

                        <td> <a type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModal<?php echo e($key); ?>" data-whatever="@mdo">Remove</a> </td>
                    </tr>

                    <div class="modal fade" id="exampleModal<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Are you sure want to remove ?</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <form method="post" action="<?php echo e(route('removeCollectedBook')); ?>">
                                <?php echo csrf_field(); ?>
                              <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Book :</label>
                                <p> <?php echo e($book->book_name); ?> </p>
                                <input type="hidden" name="book_id" value="<?php echo e($book->book_id); ?>">
                            </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                  <button type="submit" class="btn btn-primary">Remove</button>
                                </div>
                            </form>
                          </div>

                        </div>
                      </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.HomeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>