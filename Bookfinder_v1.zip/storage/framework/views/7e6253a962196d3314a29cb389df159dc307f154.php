<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
        <link rel="stylesheet" href="/css/master.css">
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="css/sb-admin.css" rel="stylesheet">
        <link rel="stylesheet" href="css/style.css">
         <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    </head>
    <body>

        <!-- Menubar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-dark" id="id_1">
            <a id="logo_main" class="navbar-brand" href="#">Book Tracker</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav" id="navbar_link">
                    <a class="nav-item nav-link li_space font-weight-light" href="#">Home</a>
                    <a class="nav-item nav-link li_space font-weight-light" href="#">My Profile</a>
                    <a class="nav-item nav-link li_space font-weight-light" href="#">Settings</a>
                </div>

                <form class="form" id="login_reg_btn">
                    <a class="btn btn-outline-success" href="<?php echo e(route('logout')); ?>">Logout</a>
                </form>
            </div>
        </nav>

        <!-- Page Content -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3">
                    <h2 class="my-4 font-weight-light"> <span class="badge badge-secondary">User Logged - <?php echo $__env->yieldContent('user_fullname'); ?></span> </h2>
                    <div class="list-group">
                        <a href="<?php echo e(route('MyAddedBooks')); ?>" class="list-group-item <?php echo $__env->yieldContent('my_added_book_page'); ?>">
                            <i class="fa fa-fw fa-align-justify"></i>
                            My Added Books
                        </a>
                        <a href="#" class="list-group-item <?php echo $__env->yieldContent('all_books_page'); ?>">
                            <i class="fa fa-fw fa-plus-circle"></i>
                            Browse All Books
                        </a>
                        <a href="#" class="list-group-item <?php echo $__env->yieldContent('want_to_read_page'); ?>">
                            <i class="fa fa-fw fa-user-plus"></i>
                            Want To Read
                        </a>
                        <a href="#" class="list-group-item <?php echo $__env->yieldContent('my_collection_page'); ?>">
                            <i class="fa fa-fw fa-envelope"></i>
                            Books in my collection
                        </a>
                        <a href="<?php echo e(route('AddBooks')); ?>" class="list-group-item <?php echo $__env->yieldContent('add_book_page'); ?>">
                            <i class="fa fa-fw fa-plus-circle"></i>
                            Add New Books
                        </a>
                    </div>
                </div>
                <!-- /.col-lg-3 -->

                <div class="col-lg-9">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    </body>
</html>
