<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('admin')->admin_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('userlist_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 id="page-heading">All User List</h1>
    <hr>
    <div class="">

        <!-- Search Option-->
        <form class="row" method="post" action="<?php echo e(route('searchUser')); ?>">
            <?php echo csrf_field(); ?>
          <div class="form-group col-10">
            <input type="text" name="userName" class="form-control" placeholder="Search User">
          </div>
          <div class="col-2">
              <button type="submit" class="btn btn-outline-info btn-block">Search</button>
          </div>
        </form>

        <div id="msg_padding">
            <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <table class="table table-bordered table-sm table-hover">
            <tr>
                <th scope="col">#</th>
                <th scope="col" class="make_text_center">User Full Name</th>
                <th scope="col" class="make_text_center">User Email </th>
                <th scope="col" class="make_text_center">User Status</th>
                <th scope="col" class="make_text_center">View Details </th>
            </tr>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($user->user_fullname); ?></td>
                        <td><?php echo e($user->user_email); ?></td>
                        <td class="make_text_center"><?php echo e($user->user_status); ?> </td>
                        <td class="make_text_center"><a href="<?php echo e(route('showUserInfo', ['id'=> $user->user_id])); ?>" class="btn btn-success">Show</a> </td>
                    </tr>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>