<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
        <link rel="stylesheet" href="/css/master.css">
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="css/sb-admin.css" rel="stylesheet">
        <link rel="stylesheet" href="css/style.css">
         <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    </head>
    <body>

        <!-- Menubar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-dark" id="id_1">
            <a id="logo_main" class="navbar-brand" href="#">Book Tracker</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav" id="navbar_link">
                    <a class="nav-item nav-link li_space" href="#">Link 1</a>
                    <a class="nav-item nav-link li_space" href="#">Link 2</a>
                    <a class="nav-item nav-link li_space" href="#">Link 3</a>
                    <a class="nav-item nav-link li_space" href="#">Link 4</a>
                </div>

                <form class="form" id="login_reg_btn">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Logout</button>
                </form>
            </div>
        </nav>

        <!-- Page Content -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3">
                    <h1 class="my-4">User - <?php echo $__env->yieldContent('user_fullname'); ?></h1>
                    <div class="list-group">
                        <a href="#" class="list-group-item active">
                            <i class="fa fa-fw fa-align-justify"></i>
                            Food List
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-fw fa-plus-circle"></i>
                            Add Item
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-fw fa-user-plus"></i>
                            Add Category
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-fw fa-envelope"></i>
                            Message
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-fw fa-wrench"></i>
                            Page Settings
                        </a>
                    </div>
                </div>
                <!-- /.col-lg-3 -->

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    </body>
</html>
