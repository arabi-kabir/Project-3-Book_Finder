<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('admin')->admin_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('all_book_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 id="page-heading">All Book List</h1>
    <hr>
    <div class="">
        <!-- Search Option-->
        <form class="row" method="post" action="<?php echo e(route('searchBookAdmin')); ?>">
            <?php echo csrf_field(); ?>
          <div class="form-group col-10">
            <input type="text" name="bookName" class="form-control" placeholder="Search Book">
          </div>
          <div class="col-2">
              <button type="submit" class="btn btn-outline-info btn-block">Search</button>
          </div>
        </form>

        <div id="msg_padding">
            <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <table class="table table-bordered table-sm table-hover">
            <tr>
                <th scope="col">#</th>
                <th scope="col" class="make_text_center">Book Cover</th>
                <th scope="col" class="make_text_center">Book Name</th>
                <th scope="col" class="make_text_center">Writer</th>
                <th scope="col" class="make_text_center">Category</th>
                <th scope="col" class="make_text_center">Show Details</th>
            </tr>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><img src="/UploadImage/bookImage/<?php echo e($book->book_picture); ?>" width="100px" height="150px" alt="Not Found"></td>
                        <td class="make_text_center"><?php echo e($book->book_name); ?></td>
                        <td class="make_text_center"><?php echo e($book->book_writer_name); ?></td>
                        <td class="make_text_center"><?php echo e($book->book_category); ?></td>
                        <td class="make_text_center"><a href="<?php echo e(route('showBookInfoAdmin', ['id'=> $book->book_id])); ?>" class="btn btn-success">Show</a> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>