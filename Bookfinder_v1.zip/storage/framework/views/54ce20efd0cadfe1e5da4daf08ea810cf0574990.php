<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('user')->user_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('all_books_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 id="page-heading">All Books</h1>
    <hr>

    <div>
        <!-- Search Option-->
        <form class="row" method="post" action="<?php echo e(route('searchBook')); ?>">
            <?php echo csrf_field(); ?>
          <div class="form-group col-10">
            <input type="text" name="bookName" class="form-control" placeholder="Search Book">
          </div>
          <div class="col-2">
              <button type="submit" class="btn btn-outline-info btn-block">Search</button>
          </div>
        </form>
    </div>

    <div id="msg_padding">
        <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="row">
        <?php $__currentLoopData = $myBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card h-100">
                    <a href="<?php echo e(route('showBookinfo_global', ['id'=> $book->book_id])); ?>"><img class="card-img-top" src="/UploadImage/bookImage/<?php echo e($book->book_picture); ?>" width="100px" height="150px" alt="Not Found"></a>
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="<?php echo e(route('showBookinfo_global', ['id'=> $book->book_id])); ?>" class=""><?php echo e($book->book_name); ?></a>
                        </h5>
                <!--        <p class="font-weight-light"> <span class="badge badge-primary"> Category : </span>  <?php echo e($book->book_category); ?> </p>
                        <p class="font-weight-light"> <span class="badge badge-primary"> Writer : </span> <?php echo e($book->book_writer_name); ?> </p> -->
                        <p class="font-weight-light"><?php echo e($book->book_writer_name); ?></p>
                    </div>
                    <div class="card-footer">
                        <h6 class="text-muted font-weight-light"> <span class="badge badge-pill badge-info font-weight-light">Rating : <?php echo e($book->book_rating); ?> </span> </h6>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.HomeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>