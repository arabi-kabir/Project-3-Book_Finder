<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('admin')->admin_fullname); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>