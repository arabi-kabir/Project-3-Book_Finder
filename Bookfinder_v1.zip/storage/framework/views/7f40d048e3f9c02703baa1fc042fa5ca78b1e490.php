<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('admin')->admin_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('summary_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 id="page-heading">Summary</h1>
    <hr>
    <div class="">
        <h2 class="table-header">User Information</h2>
        <table class="table table-bordered table-hover">
          <tbody>
            <tr>
              <th scope="col">Number of Total User</th>
              <td><?php echo e($totalNumberofUser); ?></td>
            </tr>
            <tr>
              <th scope="col">Number of Total Active User</th>
              <td><?php echo e($numberOfActiveUser); ?></td>
            </tr>
            <tr>
              <th scope="col">Number of Total Block User</th>
              <td><?php echo e($numberOfBlockUser); ?></td>
            </tr>
          </tbody>
          <tbody>
        </table>

        <h2 class="table-header">Book Information</h2>
        <table class="table table-bordered table-hover">
          <tbody>
            <tr class="bg-info">
              <th scope="col">Number of Total Book</th>
              <td><?php echo e($totalNumberofBook); ?></td>
            </tr>
            <tr>
              <th scope="col">Science fiction</th>
              <td><?php echo e($allBook[0]); ?></td>
            </tr>
            <tr>
              <th scope="col">Drama</th>
              <td><?php echo e($allBook[1]); ?></td>
            </tr>

            <tr>
              <th scope="col">ActionandAdventure</th>
              <td><?php echo e($allBook[2]); ?></td>
            </tr>
            <tr>
              <th scope="col">Romance</th>
              <td><?php echo e($allBook[3]); ?></td>
            </tr>

            <tr>
              <th scope="col">Mystery</th>
              <td><?php echo e($allBook[4]); ?></td>
            </tr>
            <tr>
              <th scope="col">Horror</th>
              <td><?php echo e($allBook[5]); ?></td>
            </tr>

            <tr>
              <th scope="col">Guide</th>
              <td><?php echo e($allBook[6]); ?></td>
            </tr>
            <tr>
              <th scope="col">Health</th>
              <td><?php echo e($allBook[7]); ?></td>
            </tr>

            <tr>
              <th scope="col">Travel</th>
              <td><?php echo e($allBook[8]); ?></td>
            </tr>
            <tr>
              <th scope="col">Children</th>
              <td><?php echo e($allBook[9]); ?></td>
            </tr>
            <tr>
              <th scope="col">Religion, Spirituality, New Age</th>
              <td><?php echo e($allBook[10]); ?></td>
            </tr>
            <tr>
              <th scope="col">Science</th>
              <td><?php echo e($allBook[11]); ?></td>
            </tr>
            <tr>
              <th scope="col">History</th>
              <td><?php echo e($allBook[12]); ?></td>
            </tr>
            <tr>
              <th scope="col">Math</th>
              <td><?php echo e($allBook[13]); ?></td>
            </tr>
            <tr>
              <th scope="col">Poetry</th>
              <td><?php echo e($allBook[14]); ?></td>
            </tr>
            <tr>
              <th scope="col">Encyclopedias</th>
              <td><?php echo e($allBook[15]); ?></td>
            </tr>
            <tr>
              <th scope="col">Comics</th>
              <td><?php echo e($allBook[16]); ?></td>
            </tr>
            <tr>
              <th scope="col">Art</th>
              <td><?php echo e($allBook[17]); ?></td>
            </tr>
            <tr>
              <th scope="col">Journals</th>
              <td><?php echo e($allBook[18]); ?></td>
            </tr>
            <tr>
              <th scope="col">Biographies</th>
              <td><?php echo e($allBook[19]); ?></td>
            </tr>
            <tr>
              <th scope="col">Prayerbooks</th>
              <td><?php echo e($allBook[20]); ?></td>
            </tr>
            <tr>
              <th scope="col">Fantasy</th>
              <td><?php echo e($allBook[21]); ?></td>
            </tr>
          </tbody>
          <tbody>
        </table>


    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>