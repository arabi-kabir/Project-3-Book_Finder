<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('admin')->admin_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('blocked_user_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 id="page-heading">All User List</h1>
    <hr>
    <div class="">

        <div id="msg_padding">
            <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <table class="table table-bordered">
            <tr>
                <th scope="col">#</th>
                <th scope="col">User Full Name</th>
                <th scope="col">User Status</th>
                <th scope="col">View Details</th>
                <th scope="col">Action</th>
            </tr>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($user->user_fullname); ?></td>
                        <td> <?php echo e($user->user_status); ?> </td>
                        <td> <a href="<?php echo e(route('showUserInfo', ['id'=> $user->user_id])); ?>" class="btn btn-success">Show</a> </td>
                        <td> <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal<?php echo e($key); ?>" data-whatever="@getbootstrap">Make Active</button> </td>
                    </tr>

                    <div class="modal fade" id="exampleModal<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Are you sure want to unblock ?</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <form method="post" action="<?php echo e(route('requestBlockUser')); ?>">
                                <?php echo csrf_field(); ?>
                              <div class="form-group">
                                <label for="recipient-name" class="col-form-label">User : <?php echo e($user->user_fullname); ?> </label>
                                <input type="hidden" name="user_id" value="<?php echo e($user->user_id); ?>">

                            </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                  <button type="submit" class="btn btn-primary">Unblock</button>
                                </div>
                            </form>
                          </div>

                        </div>
                      </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>