<?php $__env->startSection('user_fullname'); ?>
    <?php echo e(session('user')->user_fullname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('my_added_book_page'); ?>
    active
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.HomeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>